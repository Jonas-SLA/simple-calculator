const { evaluate } = require('mathjs');

class CalcService {
    static calculate(expression) {
        try {
            const result = evaluate(expression);
            
            if (result === Infinity || result === -Infinity) {
                throw new Error("Division by zero or overflow");
            }
            if (isNaN(result)) {
                throw new Error("Invalid mathematical operation");
            }
            
            return result;
        } catch (error) {
            throw new Error("Failed to evaluate expression");
        }
    }
}

module.exports = CalcService;
